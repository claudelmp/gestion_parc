<h2> <a href="<?php echo WEBROOT; ?>index.php?action=liste">Liste</a> </h2>
 <h2> <a href="<?php echo WEBROOT; ?>index.php?action=formulaire_recherche">Recherche</a> </h2>
